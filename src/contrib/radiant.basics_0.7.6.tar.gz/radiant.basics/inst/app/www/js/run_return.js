// based on http://stackoverflow.com/a/32340906/1974918
// and http://stackoverflow.com/a/8774101/1974918
$(document).keydown(function(event) {
  if ($("#clt_resample").is(":visible") && (event.metaKey || event.ctrlKey) && event.keyCode == 13) {
    $("#clt_resample").click();
  }
});

$(document).keydown(function(event) {
  if ($("#compare_means_report").is(":visible") && event.altKey && event.keyCode == 13) {
    $("#compare_means_report").click();
  } else if ($("#compare_props_report").is(":visible") && event.altKey && event.keyCode == 13) {
    $("#compare_props_report").click();
  } else if ($("#correlation_report").is(":visible") && event.altKey && event.keyCode == 13) {
    $("#correlation_report").click();
  } else if ($("#cross_tabs_report").is(":visible") && event.altKey && event.keyCode == 13) {
    $("#cross_tabs_report").click();
  } else if ($("#goodness_report").is(":visible") && event.altKey && event.keyCode == 13) {
    $("#goodness_report").click();
  } else if ($("#prob_calc_report").is(":visible") && event.altKey && event.keyCode == 13) {
    $("#prob_calc_report").click();
  } else if ($("#single_mean_report").is(":visible") && event.altKey && event.keyCode == 13) {
    $("#single_mean_report").click();
  } else if ($("#single_prop_report").is(":visible") && event.altKey && event.keyCode == 13) {
    $("#single_prop_report").click();
  }
});
