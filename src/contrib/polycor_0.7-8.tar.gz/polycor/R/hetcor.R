# last modified 5 Dec 07 by J. Fox

"hetcor" <-
function(data, ..., ML=FALSE, std.err=TRUE, bins=4, pd=TRUE){
  UseMethod("hetcor")
  }
