> Estimate a Naive Bayes model

<!-- http://lab.rady.ucsd.edu/sawtooth/RBusinessAnalytics/logit_models.html -->
