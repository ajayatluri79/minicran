#ifndef WIN_R_BUILD
#if __cplusplus < 201103L
#error Error: ranger requires a real C++11 compiler. You probably have to update gcc.
#endif
#endif

