#ifndef RANGER_VERSION
#define RANGER_VERSION "0.6.0"
#endif
