#' radiant
#'
#' @name radiant
#' @docType package
#' @import radiant.data radiant.design radiant.basics radiant.model radiant.multivariate shiny
#' @importFrom import from
NULL
