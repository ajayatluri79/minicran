#' Launch Radiant in the default browser
#'
#' @details See \url{http://radiant-rstats.github.io/docs} for documentation and tutorials
#'
#' @export
radiant <- function() {
  if (!"package:radiant" %in% search())
    if (!require(radiant)) stop("Calling radiant start function but radiant is not installed.")
  runApp(system.file("app", package = "radiant"), launch.browser = TRUE)
}

#' Update Radiant
#' @export
update_radiant <- function() {
  ## cleanup old session files
  unlink("~/radiant.sessions/*.rds", force = TRUE)

  ## avoid problems with loaded packages
  system(paste0(Sys.which("R"), " -e \"install.packages('radiant', repos = 'https://radiant-rstats.github.io/minicran', type = 'binary')\""))

  ## Restarting Rstudio session from http://stackoverflow.com/a/25934774/1974918
  ret <- .rs.restartR()
}
