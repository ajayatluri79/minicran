> Save, share, or view state

Save the state of the app to disk. See the help file for the <a href="/radiant/data/manage.html" target="_blank">_Data > Manage_</a> tab for details.
