# CHANGES IN radiant.basics VERSION 0.7

## NEW FEATURES

## BUG FIXES

- Fixed correlation dropdown. Correlations did not change when method was changed (thanks @Fiordmaster)
- Convert numeric bounds to integer in Probability calculator > Binomial to avoid warnings
