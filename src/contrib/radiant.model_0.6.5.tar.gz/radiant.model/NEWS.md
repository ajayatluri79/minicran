# CHANGES IN radiant.model VERSION 0.6.5 (unreleased)

## NEW FEATURES

## BUG FIXES

- Remove \\r and special characters from strings in r_data and r_state 
