# CHANGES IN radiant.basics VERSION 0.6.2 (unreleased)

## NEW FEATURES

## BUG FIXES

- Fixed correlation dropdown. Correlations did not change when method was changed (thanks @Fiordmaster)
