globalVariables(".rs.restartR")

#' radiant
#'
#' @name radiant
#' @docType package
#' @import radiant.data radiant.design radiant.basics radiant.model radiant.multivariate shiny
#' @importFrom psych corr.test KMO cortest.bartlett fa.sort principal
#' @importFrom AlgDesign optFederov
#' @importFrom import from
#' @importFrom utils new.packages
NULL
