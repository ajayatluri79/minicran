# CHANGES IN radiant VERSION 0.7

Updated dependency requirements for radiant menus contained in packages radiant.data, radiant.design, radiant.basics, radiant.model, and radiant.multivariate
