# CHANGES IN radiant.design VERSION 0.7 (unreleased)

## Feature
- option to set random seed in Design > Sampling

## BUG FIXES
- Fix for random seed when input is NA
- Cleanup report arguments for sample size calculations


