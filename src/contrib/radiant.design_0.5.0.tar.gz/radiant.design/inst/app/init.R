## urls for menu
r_url_list <- getOption("radiant.url.list")
r_url_list[["Random sampling"]] <- "design/sampling/"
r_url_list[["Sample size (single)"]] <- "design/sample-size/"
r_url_list[["Sample size (compare)"]] <- "design/sample-size-comp/"
r_url_list[["Design of Experiments"]] <- "design/doe/"
options(radiant.url.list = r_url_list); rm(r_url_list)

## design menu
design_ui <-
	tagList(
	  navbarMenu("Design",
	    "DOE",
	    tabPanel("Design of Experiments", uiOutput("doe")),
	    "----", "Sample",
	    tabPanel("Random sampling", uiOutput("sampling")),
	    tabPanel("Sample size (single)", uiOutput("sample_size")),
	    tabPanel("Sample size (compare)", uiOutput("sample_size_comp"))
	  )
	)

