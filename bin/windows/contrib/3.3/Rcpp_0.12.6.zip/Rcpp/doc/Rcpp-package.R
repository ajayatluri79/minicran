### R code from vignette source 'Rcpp-package.Rnw'

###################################################
### code chunk number 1: version
###################################################
prettyVersion <- packageDescription("Rcpp")$Version
prettyDate <- format(Sys.Date(), "%B %e, %Y")
require(Rcpp)
require(highlight)


###################################################
### code chunk number 2: tree (eval = FALSE)
###################################################
## Rcpp.package.skeleton("mypackage")


