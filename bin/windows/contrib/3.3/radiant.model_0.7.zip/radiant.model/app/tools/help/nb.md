> Estimate a Naive Bayes model

