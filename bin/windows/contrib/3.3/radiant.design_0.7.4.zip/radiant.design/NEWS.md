# CHANGES IN radiant.design VERSION 0.7.2

## Feature
- option to set random seed in Design > Sampling
- UI updates for DOE

## BUG FIXES
- Fix for random seed when input is NA
- Cleanup report arguments for sample size calculations
- Print full factorial up to 5,000 lines
- Check that return value from optFederov was not a try-error
