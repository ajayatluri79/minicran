# ModelMetrics 1.1.0

* added Matthews correlation coefficient (`mcc`)
* added multiclass auc (`mauc` )
* lots more tests
* fixed bug when rank ties were present in `auc` (#10)
* added code to handle different classes in functions


# ModelMetrics 1.0.0
* Refactor `common_by()` (#1928).
