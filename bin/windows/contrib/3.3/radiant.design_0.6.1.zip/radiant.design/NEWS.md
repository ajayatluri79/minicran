# CHANGES IN radiant.design VERSION 0.6.1 (unreleased)

## BUG FIXES
- Fix for random seed when input is NA
- Cleanup report arguments for sample size calculations


