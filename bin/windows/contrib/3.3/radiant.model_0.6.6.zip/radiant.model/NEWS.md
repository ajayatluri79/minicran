# CHANGES IN radiant.model VERSION 0.6.5 (unreleased)

## NEW FEATURES

## BUG FIXES

- Remove \\r and special characters from strings in r_data and r_state 
- Multiple tooltips in sequence in Decision Analysis
- Decision Analysis plot size in PDF was too small
- Replace histogram by distribution in regression plots
- Fix bug in regex for overlapping labels in variables section of Model > Decision Analysis
- Fixes for model with only an intercept (e.g., after stepwise regression)
