#ifndef SYMEIGS_H
#define SYMEIGS_H

#ifdef __cplusplus
#include <Spectra/SymEigsSolver.h>
#endif

#endif /* SYMEIGS_H */
