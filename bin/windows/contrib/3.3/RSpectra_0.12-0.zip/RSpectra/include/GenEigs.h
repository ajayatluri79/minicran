#ifndef GENEIGS_H
#define GENEIGS_H

#ifdef __cplusplus
#include <Spectra/GenEigsSolver.h>
#endif

#endif /* GENEIGS_H */
