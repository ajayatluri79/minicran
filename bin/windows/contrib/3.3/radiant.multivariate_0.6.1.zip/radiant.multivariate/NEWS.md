# CHANGES IN radiant.multivariate VERSION 0.6.1 (unreleased)

## NEW FEATURES
- Added k-medians, from the Gmedians package, as an option in _Multivariate > K-clustering_

## BUG FIXES

## DEPRECATED
- kmeans_clus was replaced by kclus
- hier_clus was replaced by hclus
