Blob.js
==============

Blob.js implements the W3C [`Blob`][1] interface in browsers that do
not natively support it.

![Tracking image](https://in.getclicky.com/212712ns.gif)

  [1]: https://developer.mozilla.org/en-US/docs/Web/API/Blob
